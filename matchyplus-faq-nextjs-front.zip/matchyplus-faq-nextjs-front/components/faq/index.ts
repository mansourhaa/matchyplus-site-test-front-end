export { default as FaqPage } from './FaqPage';
export type { FaqContent, FaqCategory, FaqItem, SupportedLocale } from './types';
