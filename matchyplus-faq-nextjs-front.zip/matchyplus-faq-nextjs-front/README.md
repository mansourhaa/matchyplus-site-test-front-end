# Matchy+ FAQ — package front Next.js

Package front uniquement, généré depuis le HTML FAQ trilingue fourni.

## Contenu
- `components/faq/FaqPage.tsx` : composant client TSX, recherche, accordéons accessibles et JSON-LD optionnel.
- `components/faq/faq.module.css` : styles isolés par CSS Module.
- `components/faq/types.ts` : types TypeScript.
- `locales/{fr,en,ar}/faq.json` : contenu complet, 20 questions par langue.

## Installation
Copier `components/faq` et `locales` dans le projet. Aucun package supplémentaire n'est requis.

## Exemple d'utilisation
```tsx
import { FaqPage } from '@/components/faq';
import faqFr from '@/locales/fr/faq.json';

export default function Page() {
  return <FaqPage locale="fr" content={faqFr} />;
}
```

Pour un système i18n existant, charger dynamiquement le bon JSON puis le passer dans `content`. Utiliser `contactHref` si la route contact réelle diffère. Mettre `includeJsonLd={false}` si le projet gère déjà les données structurées ailleurs.

## Contrôles recommandés
- Vérifier la route `/contact`.
- Vérifier les affirmations produit (prix, Wallet, vérification, confidentialité) avec les responsables métier/juridique.
- Tester clavier, lecteur d'écran et affichage arabe RTL.
- Le titre et la description SEO sont fournis dans chaque JSON, mais leur injection dans `<head>` reste à la charge de la page Next.js.
