import { Navbar } from "@/components/matchy/navbar"
import { Hero } from "@/components/matchy/hero"
import { Features } from "@/components/matchy/features"
import { Security } from "@/components/matchy/security"
import { Explore } from "@/components/matchy/explore"
import { Steps } from "@/components/matchy/steps"
import { Cta } from "@/components/matchy/cta"
import { Footer } from "@/components/matchy/footer"

export default function Page() {
  return (
    <main className="overflow-x-hidden bg-background">
      <Navbar />
      <Hero />
      <Features />
      <Security />
      <Explore />
      <Steps />
      <Cta />
      <Footer />
    </main>
  )
}
