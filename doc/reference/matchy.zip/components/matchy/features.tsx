import { Briefcase, Users, TrendingUp, Lightbulb } from "lucide-react"
import { Reveal, Parallax } from "./motion"
import { PhoneFrame } from "./phone-frame"
import { ObjectivesScreen } from "./screens"

const left = [
  {
    icon: Briefcase,
    title: "Trouver un job",
    text: "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore.",
  },
  {
    icon: TrendingUp,
    title: "Investir dans des projets",
    text: "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore.",
  },
]

const right = [
  {
    icon: Users,
    title: "Trouvez des freelancers",
    text: "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore.",
  },
  {
    icon: Lightbulb,
    title: "Chercher de l'inspiration",
    text: "Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore.",
  },
]

function Feature({
  icon: Icon,
  title,
  text,
  align,
  delay,
}: {
  icon: typeof Briefcase
  title: string
  text: string
  align: "left" | "right"
  delay: number
}) {
  return (
    <Reveal direction={align} delay={delay} className={align === "right" ? "md:text-left" : "md:text-right"}>
      <div className={`flex flex-col ${align === "right" ? "md:items-start" : "md:items-end"}`}>
        <span className="grid h-14 w-14 place-items-center rounded-full bg-brand-teal text-white shadow-lg shadow-brand-teal/30">
          <Icon className="h-6 w-6" />
        </span>
        <h3 className="mt-4 text-lg font-semibold text-brand-navy">{title}</h3>
        <div className="mt-1 h-0.5 w-10 rounded bg-brand-teal/50" />
        <p className="mt-3 max-w-[240px] text-sm leading-relaxed text-muted-foreground">{text}</p>
      </div>
    </Reveal>
  )
}

export function Features() {
  return (
    <section className="mx-auto max-w-6xl px-5 py-20">
      <Reveal className="mx-auto max-w-2xl text-center">
        <div className="mx-auto mb-4 h-1 w-10 rounded bg-brand-teal" />
        <h2 className="text-balance text-3xl font-bold text-brand-blue md:text-4xl">
          une meilleur solution pour Matchy autour du monde
        </h2>
        <p className="mt-4 text-pretty leading-relaxed text-muted-foreground">
          Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et
          dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum.
        </p>
      </Reveal>

      <div className="mt-16 grid grid-cols-1 items-center gap-10 md:grid-cols-3">
        <div className="flex flex-col gap-14">
          {left.map((f, i) => (
            <Feature key={f.title} {...f} align="left" delay={i * 0.1} />
          ))}
        </div>

        <Parallax speed={40} className="flex justify-center">
          <PhoneFrame>
            <ObjectivesScreen />
          </PhoneFrame>
        </Parallax>

        <div className="flex flex-col gap-14">
          {right.map((f, i) => (
            <Feature key={f.title} {...f} align="right" delay={i * 0.1} />
          ))}
        </div>
      </div>
    </section>
  )
}
