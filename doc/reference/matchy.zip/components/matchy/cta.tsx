import { Download, Apple, Play } from "lucide-react"
import { Reveal, Parallax } from "./motion"
import { PhoneFrame } from "./phone-frame"
import { ContactsScreen } from "./screens"

function StoreButton({
  icon: Icon,
  top,
  bottom,
}: {
  icon: typeof Apple
  top: string
  bottom: string
}) {
  return (
    <a
      href="#"
      className="flex items-center gap-2 rounded-lg bg-brand-navy px-4 py-2.5 text-white transition-transform hover:scale-[1.03]"
    >
      <Icon className="h-6 w-6" />
      <span className="text-left leading-tight">
        <span className="block text-[10px] opacity-80">{top}</span>
        <span className="block text-sm font-semibold">{bottom}</span>
      </span>
    </a>
  )
}

export function Cta() {
  return (
    <section className="relative mt-16 bg-gradient-to-br from-brand-blue to-brand-teal">
      <div className="mx-auto grid max-w-6xl grid-cols-1 items-center gap-8 px-5 pb-16 pt-4 md:grid-cols-2">
        <Parallax speed={60} className="flex justify-center md:justify-start">
          <div className="-mt-24">
            <PhoneFrame>
              <ContactsScreen />
            </PhoneFrame>
          </div>
        </Parallax>

        <Reveal direction="left" className="text-white">
          <div className="mb-3 flex items-center gap-2 text-sm font-medium text-white/80">
            <Download className="h-4 w-4" /> Download Now
          </div>
          <h2 className="text-balance text-3xl font-bold leading-tight md:text-4xl">
            Rencontrez Des Professionnels Inspirants Sur Matchy
          </h2>
          <p className="mt-4 max-w-md text-pretty leading-relaxed text-white/85">
            Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et
            dolore magna aliquyam.
          </p>
          <div className="mt-6 flex flex-wrap gap-3">
            <StoreButton icon={Play} top="ANDROID APP ON" bottom="Google play" />
            <StoreButton icon={Apple} top="Download on the" bottom="App Store" />
          </div>
        </Reveal>
      </div>
    </section>
  )
}
