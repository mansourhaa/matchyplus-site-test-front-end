"use client"

import { useRef } from "react"
import { Reveal, motion, useMounted, useScroll, useTransform } from "./motion"
import { PhoneFrame } from "./phone-frame"
import { ExploreScreen, ProfileScreen } from "./screens"

function CascadingPhones() {
  const ref = useRef<HTMLDivElement>(null)
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start end", "end start"],
  })
  const yFront = useTransform(scrollYProgress, [0, 1], [60, -60])
  const yBack = useTransform(scrollYProgress, [0, 1], [-40, 40])

  return (
    <div ref={ref} className="relative flex min-h-[440px] items-center justify-center">
      <motion.div style={{ y: yFront }} className="relative z-10">
        <PhoneFrame className="rotate-[-4deg]">
          <ExploreScreen />
        </PhoneFrame>
      </motion.div>
      <motion.div style={{ y: yBack }} className="absolute right-0 top-16 z-20 hidden scale-90 sm:block">
        <PhoneFrame className="rotate-[6deg]">
          <ProfileScreen />
        </PhoneFrame>
      </motion.div>
    </div>
  )
}

function StaticPhones() {
  return (
    <div className="relative flex min-h-[440px] items-center justify-center">
      <div className="relative z-10">
        <PhoneFrame className="rotate-[-4deg]">
          <ExploreScreen />
        </PhoneFrame>
      </div>
      <div className="absolute right-0 top-16 z-20 hidden scale-90 sm:block">
        <PhoneFrame className="rotate-[6deg]">
          <ProfileScreen />
        </PhoneFrame>
      </div>
    </div>
  )
}

export function Explore() {
  const mounted = useMounted()

  return (
    <section className="relative overflow-hidden py-20">
      <div
        className="pointer-events-none absolute right-0 top-1/3 z-0 h-80 w-80 translate-x-1/3 rounded-[3rem] bg-gradient-to-br from-brand-teal to-brand-blue opacity-20"
        style={{ transform: "translateX(35%) rotate(-15deg)" }}
        aria-hidden="true"
      />
      <div className="relative z-10 mx-auto grid max-w-6xl grid-cols-1 items-center gap-12 px-5 md:grid-cols-2">
        <Reveal direction="right">
          <div className="mb-5 h-1 w-10 rounded bg-brand-teal" />
          <h2 className="text-balance text-3xl font-bold text-brand-blue md:text-4xl">Découvrir Matchy explore</h2>
          <p className="mt-5 max-w-lg text-pretty leading-relaxed text-muted-foreground">
            Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et
            dolore magna aliquyam erat, sed diam voluptua.
          </p>
        </Reveal>

        {mounted ? <CascadingPhones /> : <StaticPhones />}
      </div>
    </section>
  )
}
