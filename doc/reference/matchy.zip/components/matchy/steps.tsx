import { Reveal } from "./motion"

const steps = [
  {
    n: "1",
    title: "Swiper",
    text: "Notre algorithme fait tout le travail pour vous proposer une sélection quotidienne de profils pertinents à rencontrer. Votre pouce fait le reste.",
  },
  {
    n: "2",
    title: "Choisir un profil",
    text: "Vous \"matchez\" lorsque l'intérêt de se rencontrer est mutuel. Nous façonnons une friend-zone professionnelle internationale. Et pour une fois, vous serez heureux d'y être !",
  },
  {
    n: "3",
    title: "Entrer en contact",
    text: "Brisez la glace en quelques secondes. Rencontrez votre match autour d'un café (ou au téléphone). Laissez la magie opérer.",
  },
]

export function Steps() {
  return (
    <section className="mx-auto grid max-w-6xl grid-cols-1 gap-12 px-5 py-20 md:grid-cols-2 md:items-start">
      <Reveal direction="right" className="md:sticky md:top-28">
        <div className="mb-5 h-1 w-10 rounded bg-brand-teal" />
        <h2 className="text-balance text-3xl font-bold text-brand-blue md:text-4xl">
          Comment ca marche les étapes ..
        </h2>
        <p className="mt-5 max-w-md text-pretty leading-relaxed text-muted-foreground">
          Lorem ipsum dolor sit amet, consetetur sadipscing elitr, sed diam nonumy eirmod tempor invidunt ut labore et
          dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo dolores et ea rebum. Stet
          kasd gubergren, no sea takimata sanctus est.
        </p>
      </Reveal>

      <ol className="relative space-y-10 border-l-2 border-dashed border-brand-teal/40 pl-8">
        {steps.map((s, i) => (
          <Reveal key={s.n} direction="left" delay={i * 0.1}>
            <li className="relative">
              <span className="absolute -left-[3.05rem] grid h-9 w-9 place-items-center rounded-full bg-brand-teal text-sm font-bold text-white shadow-lg shadow-brand-teal/30">
                {s.n}
              </span>
              <h3 className="text-lg font-semibold text-brand-teal">{s.title}</h3>
              <p className="mt-2 max-w-md text-sm leading-relaxed text-muted-foreground">{s.text}</p>
            </li>
          </Reveal>
        ))}
      </ol>
    </section>
  )
}
