import { Reveal, Parallax } from "./motion"
import { PhoneFrame } from "./phone-frame"
import { FaceScanScreen } from "./screens"

export function Security() {
  return (
    <section className="relative overflow-hidden py-20">
      {/* brand accent shape */}
      <div
        className="pointer-events-none absolute left-0 top-1/2 z-0 h-72 w-72 -translate-x-1/3 -translate-y-1/2 rounded-[3rem] bg-gradient-to-br from-brand-blue to-brand-teal opacity-20"
        style={{ transform: "translate(-30%, -50%) rotate(20deg)" }}
        aria-hidden="true"
      />
      <div className="relative z-10 mx-auto grid max-w-6xl grid-cols-1 items-center gap-12 px-5 md:grid-cols-2">
        <Parallax speed={50} className="flex justify-center md:justify-start">
          <PhoneFrame dark>
            <FaceScanScreen />
          </PhoneFrame>
        </Parallax>

        <Reveal direction="left">
          <div className="mb-5 h-1 w-10 rounded bg-brand-teal" />
          <h2 className="text-balance text-3xl font-bold text-brand-blue md:text-4xl">
            Profil 100% sécurisé par l&apos;Option De vérification de l&apos;identité
          </h2>
          <p className="mt-5 max-w-lg text-pretty leading-relaxed text-muted-foreground">
            Garder vos données et votre propriété en sécurité avec technologie de reconnaissance faciale eirmod tempor
            invidunt ut labore et dolore magna aliquyam erat, sed diam voluptua. At vero eos et accusam et justo duo
            dolores et ea rebum. Stet clita aliquyam erat, sed diam.
          </p>
          <a href="#" className="mt-4 inline-block text-sm font-semibold text-brand-teal hover:underline">
            En savoir plus
          </a>
        </Reveal>
      </div>
    </section>
  )
}
