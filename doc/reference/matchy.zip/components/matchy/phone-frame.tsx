import type { ReactNode } from "react"
import { cn } from "@/lib/utils"
import { Signal, Wifi, BatteryFull } from "lucide-react"

export function PhoneFrame({
  children,
  className,
  dark = false,
  time = "9:41",
}: {
  children: ReactNode
  className?: string
  dark?: boolean
  time?: string
}) {
  return (
    <div
      className={cn(
        "relative w-[248px] shrink-0 rounded-[2.5rem] border-[6px] border-foreground/90 bg-foreground/90 p-1 shadow-2xl shadow-brand-navy/30",
        className,
      )}
    >
      <div
        className={cn(
          "relative overflow-hidden rounded-[2rem]",
          dark ? "bg-neutral-900 text-white" : "bg-white text-brand-navy",
        )}
      >
        {/* notch */}
        <div className="pointer-events-none absolute left-1/2 top-0 z-20 h-5 w-28 -translate-x-1/2 rounded-b-2xl bg-foreground/90" />
        {/* status bar */}
        <div
          className={cn(
            "flex items-center justify-between px-5 pb-1 pt-2 text-[10px] font-semibold",
            dark ? "text-white" : "text-brand-navy",
          )}
        >
          <span>{time}</span>
          <div className="flex items-center gap-1">
            <Signal className="h-3 w-3" />
            <Wifi className="h-3 w-3" />
            <BatteryFull className="h-3 w-3" />
          </div>
        </div>
        {children}
      </div>
    </div>
  )
}
