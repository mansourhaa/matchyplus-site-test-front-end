'use client'

import Link from 'next/link'
import { useState } from 'react'
import { Menu, X, ChevronDown, ArrowUpRight } from 'lucide-react'

import { labels, type Locale } from '@/lib/i18n'

const languageOptions = [
  { value: 'fr', label: 'Français', flag: '🇫🇷' },
  { value: 'en', label: 'English', flag: '🇬🇧' },
  { value: 'ar', label: 'العربية', flag: '🇹🇳' },
] as const

function Logo({ footer = false }: { footer?: boolean }) {
  return <img className={`brand-logo${footer ? ' brand-logo-footer' : ''}`} src="/matchy-logo.png" alt="Matchy+" />
}

export function Header({ locale = 'fr' }: { locale?: Locale }) {
  const [open, setOpen] = useState(false)
  const copy = labels[locale]
  const href = (path: string) => `${path}?lang=${locale}`
  return (
    <header className="site-header">
      <div className="container header-inner">
        <Link href={`/?lang=${locale}`} className="brand" aria-label="Matchy Plus home">
          <Logo />
        </Link>
        <nav className="desktop-nav" aria-label="Main navigation">
          <Link href="#services">{copy.services}</Link><Link href="#explore">{copy.explore}</Link><Link href="#how">{copy.how}</Link><Link href="#download">{copy.download}</Link>
          <div className="language-picker"><span aria-hidden="true">{languageOptions.find((option) => option.value === locale)?.flag}</span><ChevronDown size={14} /><select aria-label="Language" defaultValue={locale} onChange={(e) => { window.location.href = `${window.location.pathname}?lang=${e.target.value}` }}>{languageOptions.map((option) => <option key={option.value} value={option.value}>{option.flag} {option.label}</option>)}</select></div>
          <Link className="nav-cta" href={href('/devenir-partenaire')}>{copy.cta} <ArrowUpRight size={15} /></Link>
        </nav>
        <button className="mobile-toggle" aria-label={open ? 'Close menu' : 'Open menu'} onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
      </div>
      {open && <div className="mobile-menu"><Link href="#services" onClick={() => setOpen(false)}>{copy.services}</Link><Link href="#explore" onClick={() => setOpen(false)}>{copy.explore}</Link><Link href="#how" onClick={() => setOpen(false)}>{copy.how}</Link><Link href={href('/faq')}>{copy.faq}</Link><Link href={href('/contact')}>{copy.contact}</Link><Link href={href('/devenir-partenaire')}>{copy.partner}</Link><Link href={href('/suppression-compte')}>{copy.delete}</Link><div className="mobile-langs">{languageOptions.map((option) => <Link key={option.value} href={`?lang=${option.value}`} aria-label={option.label}><span aria-hidden="true">{option.flag}</span> {option.value.toUpperCase()}</Link>)}</div></div>}
    </header>
  )
}

export function Footer({ locale = 'fr' }: { locale?: Locale }) {
  const copy = labels[locale]
  return <footer className="site-footer"><div className="container footer-grid"><div><Link href="/" className="brand footer-brand"><Logo footer /></Link><p>{locale === 'ar' ? 'منصة عموم إفريقيا للخدمات المحلية.' : locale === 'en' ? 'The pan-African platform for local services.' : 'La plateforme panafricaine des services locaux.'}</p></div><div><h3>{locale === 'ar' ? 'اكتشف' : locale === 'en' ? 'Discover' : 'Découvrir'}</h3><Link href="#services">{copy.services}</Link><Link href="#explore">{copy.explore}</Link><Link href="#how">{copy.how}</Link><Link href="#download">{copy.download}</Link></div><div><h3>{locale === 'ar' ? 'روابط مفيدة' : locale === 'en' ? 'Useful links' : 'Liens utiles'}</h3><Link href={locale === 'fr' ? '/faq' : `/faq?lang=${locale}`}>{copy.faq}</Link><Link href={locale === 'fr' ? '/contact' : `/contact?lang=${locale}`}>{copy.contact}</Link><Link href={locale === 'fr' ? '/devenir-partenaire' : `/devenir-partenaire?lang=${locale}`}>{copy.partner}</Link><Link href={locale === 'fr' ? '/suppression-compte' : `/suppression-compte?lang=${locale}`}>{copy.delete}</Link></div></div><div className="container footer-bottom"><span>© 2026 Matchy+. Tous droits réservés.</span><span>Conçu pour connecter les talents locaux.</span></div></footer>
}

export function PageFrame({ children, locale = 'fr' }: { children: React.ReactNode; locale?: Locale }) { return <div dir={locale === 'ar' ? 'rtl' : 'ltr'}><Header locale={locale} />{children}<Footer locale={locale} /></div> }

export function getLocale(value?: string): Locale { return value === 'en' || value === 'ar' ? value : 'fr' }

export { labels }
