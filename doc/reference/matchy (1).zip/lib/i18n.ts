export type Locale = 'fr' | 'en' | 'ar'
export function getLocale(value?: string): Locale { return value === 'en' || value === 'ar' ? value : 'fr' }
export const labels = {
  fr: { services: 'Services', explore: 'Explorer', how: 'Utilisation', download: 'Télécharger', faq: 'FAQ', contact: 'Contact', partner: 'Devenir partenaire', delete: 'Supprimer mon compte', cta: "S'inscrire gratuitement" },
  en: { services: 'Services', explore: 'Explore', how: 'How it works', download: 'Download', faq: 'FAQ', contact: 'Contact', partner: 'Become a partner', delete: 'Delete account', cta: 'Join for free' },
  ar: { services: 'الخدمات', explore: 'استكشف', how: 'طريقة الاستخدام', download: 'تحميل', faq: 'الأسئلة الشائعة', contact: 'اتصل بنا', partner: 'كن شريكًا', delete: 'حذف الحساب', cta: 'سجّل مجانًا' },
}
