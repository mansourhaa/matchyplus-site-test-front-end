export { default as AboutPage } from './AboutPage';
export type { AboutContent, AboutAction, SupportedLocale } from './types';
