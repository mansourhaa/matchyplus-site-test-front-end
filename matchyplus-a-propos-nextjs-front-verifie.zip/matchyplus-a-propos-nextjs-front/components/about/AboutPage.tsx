import type { AboutContent, SupportedLocale } from './types';
import styles from './about.module.css';

type Props = {
  locale: SupportedLocale;
  content: AboutContent;
  customerHref?: string;
  professionalHref?: string;
  includeJsonLd?: boolean;
  baseUrl?: string;
  pagePath?: string;
};

export default function AboutPage({
  locale,
  content,
  customerHref,
  professionalHref,
  includeJsonLd = true,
  baseUrl = 'https://matchyplus.com',
  pagePath,
}: Props) {
  const path = pagePath ?? (locale === 'fr' ? '/a-propos' : `/${locale}/about`);
  const pageUrl = `${baseUrl.replace(/\/$/, '')}${path}`;
  const actionHref = (index: number, fallback: string) =>
    index === 0 ? customerHref ?? fallback : professionalHref ?? fallback;

  const jsonLd = {
    '@context': 'https://schema.org',
    '@graph': [
      {
        '@type': 'Organization',
        '@id': `${baseUrl}/#organization`,
        name: 'Matchy+',
        url: `${baseUrl}/`,
        description: content.seo.description,
        areaServed: [
          { '@type': 'Country', name: 'Tunisia' },
          { '@type': 'Place', name: 'Africa' },
        ],
        knowsAbout: [
          'Local services',
          'Professional networking',
          'Service providers',
          'Geolocation',
          'Professional visibility',
        ],
      },
      {
        '@type': 'WebSite',
        '@id': `${baseUrl}/#website`,
        url: `${baseUrl}/`,
        name: 'Matchy+',
        publisher: { '@id': `${baseUrl}/#organization` },
        inLanguage: ['fr', 'en', 'ar'],
      },
      {
        '@type': 'AboutPage',
        '@id': `${pageUrl}#webpage`,
        url: pageUrl,
        name: content.seo.title,
        description: content.seo.description,
        inLanguage: locale,
        isPartOf: { '@id': `${baseUrl}/#website` },
        about: { '@id': `${baseUrl}/#organization` },
        mainEntity: { '@id': `${baseUrl}/#organization` },
      },
      {
        '@type': 'BreadcrumbList',
        '@id': `${pageUrl}#breadcrumb`,
        itemListElement: [
          { '@type': 'ListItem', position: 1, name: 'Matchy+', item: `${baseUrl}/` },
          { '@type': 'ListItem', position: 2, name: content.hero.title, item: pageUrl },
        ],
      },
    ],
  };

  return (
    <main lang={locale} dir={locale === 'ar' ? 'rtl' : 'ltr'} className={styles.page}>
      {includeJsonLd && (
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd).replace(/</g, '\\u003c') }} />
      )}
      <header className={styles.hero}>
        <p className={styles.eyebrow}>{content.hero.eyebrow}</p>
        <h1>{content.hero.title}</h1>
        <p className={styles.lead}>{content.hero.text}</p>
        <div className={styles.actions}>
          {content.hero.actions.map((action, index) => (
            <a key={action.label} className={index === 0 ? styles.primary : styles.secondary} href={actionHref(index, action.href)}>{action.label}</a>
          ))}
        </div>
      </header>

      <div className={styles.content}>
        {content.sections.map((section) => (
          <section key={section.id} className={styles.textSection}>
            <h2>{section.title}</h2><p>{section.text}</p>
          </section>
        ))}

        <section aria-labelledby="about-principles-title">
          <h2 id="about-principles-title">{content.principles.title}</h2>
          <div className={styles.values}>
            {content.principles.items.map((item) => (
              <article key={item.id} className={styles.card}><h3>{item.title}</h3><p>{item.text}</p></article>
            ))}
          </div>
        </section>

        <section className={styles.faq} aria-labelledby="about-faq-title">
          <h2 id="about-faq-title">{content.faq.title}</h2>
          {content.faq.items.map((item) => (
            <details key={item.id}><summary>{item.question}</summary><p>{item.answer}</p></details>
          ))}
        </section>

        <section className={styles.finalCta}>
          <h2>{content.finalCta.title}</h2><p>{content.finalCta.text}</p>
          <div className={styles.actions}>
            {content.finalCta.actions.map((action, index) => (
              <a key={action.label} className={styles.secondary} href={actionHref(index, action.href)}>{action.label}</a>
            ))}
          </div>
        </section>
      </div>
    </main>
  );
}
