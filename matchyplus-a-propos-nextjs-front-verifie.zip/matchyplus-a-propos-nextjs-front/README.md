# Matchy+ — Page À propos, package front Next.js

Package front uniquement, généré depuis la source trilingue fournie.

## Contenu
- `components/about/AboutPage.tsx` : composant TSX sans dépendance externe.
- `components/about/about.module.css` : CSS Module responsive avec RTL.
- `components/about/types.ts` : types TypeScript.
- `locales/{fr,en,ar}/about.json` : contenus complets.

## Utilisation
```tsx
import { AboutPage } from '@/components/about';
import aboutFr from '@/locales/fr/about.json';

export default function Page() {
  return <AboutPage locale="fr" content={aboutFr} />;
}
```

## Props utiles
- `customerHref` et `professionalHref` : remplacent les liens d'inscription provisoires.
- `includeJsonLd={false}` : désactive le JSON-LD si le projet le gère ailleurs.
- `baseUrl` et `pagePath` : adaptent les URL du graphe Schema.org.

## Points à valider avant production
- Parcours d'inscription client et professionnel.
- Logo officiel, image Open Graph, coordonnées et réseaux sociaux. Ils ne sont pas inventés dans ce package.
- Injection des métadonnées SEO/Open Graph depuis `content.seo` dans la page Next.js.
- URLs finales FR/EN/AR et affichage mobile/RTL.
