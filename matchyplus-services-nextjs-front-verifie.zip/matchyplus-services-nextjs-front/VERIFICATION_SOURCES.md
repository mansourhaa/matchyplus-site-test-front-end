# Vérification des sources

- Correspondance exacte des contenus visibles FR/EN/AR avec le HTML.
- Par langue : 8 services, 4 étapes, 5 villes, 5 FAQ.
- SEO et Open Graph repris du document source.
- JSON-LD généré depuis les mêmes données : Organization, CollectionPage, ItemList, BreadcrumbList, FAQPage et 8 objets Service.
- Aucun moteur de recherche public ajouté.
- Routes inscription/connexion conservées et surchargeables.
- RTL arabe activé.
- Pages métier/ville vides non générées.
