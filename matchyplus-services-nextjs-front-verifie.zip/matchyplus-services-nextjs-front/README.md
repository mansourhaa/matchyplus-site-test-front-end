# Matchy+ — Page Services, package front Next.js

Contenu FR/EN/AR extrait et vérifié depuis le HTML source.

## Utilisation
```tsx
import { ServicesPage } from '@/components/services';
import servicesFr from '@/locales/fr/services.json';
export default function Page(){return <ServicesPage locale="fr" content={servicesFr}/>}
```

Props: `signupHref`, `loginHref`, `includeJsonLd`, `baseUrl`, `pagePath`.
Aucun moteur de recherche public n'est inclus. Tous les CTA restent orientés vers l'application.
Les métadonnées sont dans `content.seo`; leur injection dans `<head>` dépend du routeur Next.js.
