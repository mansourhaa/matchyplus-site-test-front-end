export {default as ServicesPage} from './ServicesPage';
export type {ServicesContent,SupportedLocale,Action} from './types';
