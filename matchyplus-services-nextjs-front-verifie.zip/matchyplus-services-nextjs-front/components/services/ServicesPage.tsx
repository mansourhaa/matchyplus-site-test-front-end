import type { ServicesContent, SupportedLocale } from './types';
import styles from './services.module.css';
type Props={locale:SupportedLocale;content:ServicesContent;signupHref?:string;loginHref?:string;includeJsonLd?:boolean;baseUrl?:string;pagePath?:string};
export default function ServicesPage({locale,content,signupHref,loginHref,includeJsonLd=true,baseUrl='https://matchyplus.com',pagePath}:Props){
 const path=pagePath??(locale==='fr'?'/services':`/${locale}/services`); const pageUrl=`${baseUrl.replace(/\/$/,'')}${path}`;
 const href=(fallback:string)=>fallback.includes('/connexion')?(loginHref??fallback):(signupHref??fallback);
 const ids=content.popular.services.map((s,i)=>({id:`${pageUrl}#service-${s.id.replace('service-','')}`,s,i}));
 const graph=[
 {'@type':'Organization','@id':`${baseUrl}/#organization`,name:'Matchy+',url:`${baseUrl}/`},
 {'@type':'CollectionPage','@id':`${pageUrl}#webpage`,url:pageUrl,name:content.seo.title,description:content.seo.description,inLanguage:locale,about:{'@id':`${baseUrl}/#organization`},mainEntity:{'@id':`${pageUrl}#services`}},
 {'@type':'ItemList','@id':`${pageUrl}#services`,name:content.popular.title,numberOfItems:ids.length,itemListElement:ids.map(({id,s,i})=>({'@type':'ListItem',position:i+1,item:{'@id':id,name:s.name}}))},
 {'@type':'BreadcrumbList','@id':`${pageUrl}#breadcrumb`,itemListElement:[{'@type':'ListItem',position:1,name:'Matchy+',item:`${baseUrl}/`},{'@type':'ListItem',position:2,name:content.popular.title,item:pageUrl}]},
 {'@type':'FAQPage','@id':`${pageUrl}#faq`,inLanguage:locale,mainEntity:content.faq.items.map(q=>({'@type':'Question',name:q.question,acceptedAnswer:{'@type':'Answer',text:q.answer}}))},
 ...ids.map(({id,s})=>({'@type':'Service','@id':id,name:s.name,description:s.description,serviceType:s.name,provider:{'@id':`${baseUrl}/#organization`},areaServed:{'@type':'Country',name:'Tunisia'}}))];
 const jsonLd={'@context':'https://schema.org','@graph':graph};
 return <main lang={locale} dir={locale==='ar'?'rtl':'ltr'} className={styles.page}>
  {includeJsonLd&&<script type="application/ld+json" dangerouslySetInnerHTML={{__html:JSON.stringify(jsonLd).replace(/</g,'\\u003c')}}/>}
  <header className={styles.hero}><strong>{content.hero.eyebrow}</strong><h1>{content.hero.title}</h1><p>{content.hero.text}</p><div className={styles.actions}>{content.hero.actions.map((a,i)=><a key={a.label} className={i===0?styles.primary:styles.secondary} href={href(a.href)}>{a.label}</a>)}</div></header>
  <section className={styles.block}><div className={styles.sectionHead}><h2>{content.popular.title}</h2><p>{content.popular.text}</p></div><div className={styles.grid}>{content.popular.services.map(s=><article key={s.id} className={styles.card}><h3>{s.name}</h3><p>{s.description}</p><ul>{s.features.map(x=><li key={x}>{x}</li>)}</ul><a href={href(s.action.href)}>{s.action.label}</a></article>)}</div></section>
  <section className={styles.block}><div className={styles.sectionHead}><h2>{content.howItWorks.title}</h2></div><div className={styles.steps}>{content.howItWorks.steps.map(s=><article key={s.id} className={styles.step}><h3>{s.title}</h3><p>{s.text}</p></article>)}</div></section>
  <section className={`${styles.block} ${styles.band}`}><div><h2>{content.professionalCta.title}</h2><p>{content.professionalCta.text}</p></div><a className={styles.primary} href={href(content.professionalCta.action.href)}>{content.professionalCta.action.label}</a></section>
  <section className={styles.block}><div className={styles.sectionHead}><h2>{content.clarity.title}</h2><p>{content.clarity.text}</p></div></section>
  <section className={styles.block}><div className={styles.sectionHead}><h2>{content.cities.title}</h2><p>{content.cities.text}</p></div><div className={styles.cities}>{content.cities.items.map(c=><span className={styles.city} key={c}>{c}</span>)}</div></section>
  <section className={`${styles.block} ${styles.faq}`}><div className={styles.sectionHead}><h2>{content.faq.title}</h2></div>{content.faq.items.map(q=><details key={q.id}><summary>{q.question}</summary><p>{q.answer}</p></details>)}</section>
  <section className={styles.final}><h2>{content.finalCta.title}</h2><p>{content.finalCta.text}</p><div className={styles.actions}>{content.finalCta.actions.map(a=><a className={styles.secondary} href={href(a.href)} key={a.label}>{a.label}</a>)}</div></section>
 </main>}
